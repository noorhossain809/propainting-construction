import { Model } from "mongoose";

export type Gender = 'male' | 'female';
export type BloodGroup = 'A+' | 'A-' | 'B+' | 'B-' | 'AB+' | 'AB-' | 'O+' | 'O-';
export type RequestStatus = 'pending' | 'cancel' | 'done';
export type RequestMessageType = 'normal' | 'urgent';

export type IRequest = {
  id: string;
  name: string;
  gender: Gender;
  contactNo: string;
  bloodGroup: BloodGroup;
  donationDate: Date;
  donationTime: string; // could also use Date if you store both date+time together
  hospitalName: string;
  patientDiseaseInfo: string;
  status: RequestStatus;
  requestMessageType: RequestMessageType;
}


export type PatientModel = Model<IRequest, Record<string, unknown>>