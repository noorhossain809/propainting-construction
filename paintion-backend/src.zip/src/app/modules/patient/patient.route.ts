import express from 'express'
import { PatientController } from './patient.controller'

const router = express.Router()

router.get('/', PatientController.getAllBloodRequest)
router.post('/request-blood', PatientController.requestBlood)


export const PatientRoutes = router