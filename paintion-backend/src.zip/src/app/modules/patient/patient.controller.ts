import { Request, Response } from "express"
import httpStatus from "http-status"
import catchAsync from "../../../shared/catchAsync"
import sendResponse from "../../../shared/sendResponse"
import { PatientService } from "./patient.service"

const requestBlood = catchAsync(async(req: Request, res: Response) => {
  
    const result = await PatientService.requestBlood(req.body)

    sendResponse(res, {
        statusCode: httpStatus.OK,
        success: true,
        message: 'Blood request successfully!',
        data: result
    })
})

const getAllBloodRequest = catchAsync(async(req: Request, res: Response) => {
  
    const result = await PatientService.getAllBloodRequest()

    sendResponse(res, {
        statusCode: httpStatus.OK,
        success: true,
        message: 'Blood request fetched successfully!',
        data: result
    })
})

export const PatientController = {
    requestBlood,
    getAllBloodRequest
}