import { IPatient } from "./patient.interface";
import { Patient } from "./patient.modal";

const requestBlood = async(payload: IPatient) => {
    const result = await Patient.create(payload)

    return result
}

const getAllBloodRequest = async() => {
    const result = await Patient.find()

    return result
}

export const PatientService = {
    requestBlood,
    getAllBloodRequest
}