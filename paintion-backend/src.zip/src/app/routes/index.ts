import express from 'express';
import { ConstructionProjectRoutes } from '../modules/constructionProject/constructionProject.route';
import { PatientRoutes } from '../modules/patient/patient.route';
import { ServiceRoutes } from '../modules/services/services.router';
import { HeroSlideRoutes } from '../modules/heroSlider/heroSlide.route';
import { ContactInfoRoutes } from '../modules/contactInfo/contactInfo.route';
import { TeamRoutes } from '../modules/our-team/team.router';
import { AuthRoutes } from '../modules/user/auth.route';



const router = express.Router();

const moduleRoutes = [
  // ... routes

  {
    path: "/patient",
    routes: PatientRoutes
  },
  
  {
    path: "/construction",
    routes: ConstructionProjectRoutes
  },
  {
    path: "/services",
    routes: ServiceRoutes
  },
  {
    path: "/hero-slides",
    routes: HeroSlideRoutes
  },
  {
    path: "/contact-info",
    routes: ContactInfoRoutes
  },
  {
    path: "/team",
    routes: TeamRoutes
  },
  {
    path: "/auth",
    routes: AuthRoutes
  },
];

moduleRoutes.forEach(route => router.use(route.path, route.routes));
export default router;
