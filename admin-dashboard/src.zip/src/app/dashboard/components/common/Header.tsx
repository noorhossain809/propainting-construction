// components/common/Header.tsx

"use client"

import { SidebarTrigger, useSidebar } from '@/components/ui/sidebar';
import { Button } from '@/components/ui/button';
import { Menu } from 'lucide-react'; // <-- Menu আইকন ইম্পোর্ট করুন
import React from 'react';

export const Header = () => {
  const { toggleSidebar } = useSidebar(); // <-- toggleSidebar হুকটি ব্যবহার করবো

  return (
    <header className="flex h-16 items-center border-b bg-white px-4 md:px-6 sticky top-0 z-10">
      {/* ডেস্কটপের জন্য ট্রিগার (আগের মতোই) */}
      <div className="hidden md:flex">
        <SidebarTrigger />
      </div>

      {/* মোবাইলের জন্য ড্রয়ার ট্রিগার (হ্যামবার্গার আইকন) */}
      <div className="md:hidden">
        <Button onClick={toggleSidebar} variant="ghost" size="icon">
          <Menu className="h-6 w-6" />
          <span className="sr-only">Open Menu</span>
        </Button>
      </div>
      
      <div className="ml-4">
        {/* এখানে হেডারের অন্যান্য কন্টেন্ট থাকবে */}
        <h4>Construction</h4>
      </div>
    </header>
  );
};