1:"$Sreact.fragment"
2:I[4604,["321","static/chunks/321-47d54e1c23400180.js","177","static/chunks/app/layout-be88ad604b5512f6.js"],"GoogleOAuthProvider"]
3:I[3087,["321","static/chunks/321-47d54e1c23400180.js","177","static/chunks/app/layout-be88ad604b5512f6.js"],"default"]
4:I[9766,[],""]
5:I[8924,[],""]
6:I[1959,[],"ClientPageRoot"]
7:I[815,["321","static/chunks/321-47d54e1c23400180.js","520","static/chunks/app/login/page-b998e79b12eb4739.js"],"default"]
a:I[4431,[],"OutletBoundary"]
c:I[5278,[],"AsyncMetadataOutlet"]
e:I[4431,[],"ViewportBoundary"]
10:I[4431,[],"MetadataBoundary"]
11:"$Sreact.suspense"
13:I[7150,[],""]
:HL["/_next/static/css/3094734b33476ff6.css","style"]
0:{"P":null,"b":"HAbIzw3iieYXnisIsueqH","p":"","c":["","login"],"i":false,"f":[[["",{"children":["login",{"children":["__PAGE__",{}]}]},"$undefined","$undefined",true],["",["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/css/3094734b33476ff6.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}]],["$","html",null,{"lang":"en","children":["$","body",null,{"className":"__variable_246ccd __variable_c29908 antialiased","children":["$","$L2",null,{"clientId":"233028814796-40qf5o82qvduse7cdmkorhcghqke1st8.apps.googleusercontent.com","children":["$","$L3",null,{"children":["$","$L4",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L5",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[[["$","title",null,{"children":"404: This page could not be found."}],["$","div",null,{"style":{"fontFamily":"system-ui,\"Segoe UI\",Roboto,Helvetica,Arial,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\"","height":"100vh","textAlign":"center","display":"flex","flexDirection":"column","alignItems":"center","justifyContent":"center"},"children":["$","div",null,{"children":[["$","style",null,{"dangerouslySetInnerHTML":{"__html":"body{color:#000;background:#fff;margin:0}.next-error-h1{border-right:1px solid rgba(0,0,0,.3)}@media (prefers-color-scheme:dark){body{color:#fff;background:#000}.next-error-h1{border-right:1px solid rgba(255,255,255,.3)}}"}}],["$","h1",null,{"className":"next-error-h1","style":{"display":"inline-block","margin":"0 20px 0 0","padding":"0 23px 0 0","fontSize":24,"fontWeight":500,"verticalAlign":"top","lineHeight":"49px"},"children":404}],["$","div",null,{"style":{"display":"inline-block"},"children":["$","h2",null,{"style":{"fontSize":14,"fontWeight":400,"lineHeight":"49px","margin":0},"children":"This page could not be found."}]}]]}]}]],[]],"forbidden":"$undefined","unauthorized":"$undefined"}]}]}]}]}]]}],{"children":["login",["$","$1","c",{"children":[null,["$","$L4",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L5",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]]}],{"children":["__PAGE__",["$","$1","c",{"children":[["$","$L6",null,{"Component":"$7","searchParams":{},"params":{},"promises":["$@8","$@9"]}],null,["$","$La",null,{"children":["$Lb",["$","$Lc",null,{"promise":"$@d"}]]}]]}],{},null,false]},null,false]},null,false],["$","$1","h",{"children":[null,[["$","$Le",null,{"children":"$Lf"}],null],["$","$L10",null,{"children":["$","div",null,{"hidden":true,"children":["$","$11",null,{"fallback":null,"children":"$L12"}]}]}]]}],false]],"m":"$undefined","G":["$13",[]],"s":false,"S":true}
8:{}
9:"$0:f:0:1:2:children:2:children:1:props:children:0:props:params"
f:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]
b:null
14:I[622,[],"IconMark"]
d:{"metadata":[["$","title","0",{"children":"Admin Dashboard | Pro Painting Construction"}],["$","meta","1",{"name":"description","content":"Admin dashboard for managing Pro Painting Construction's website content, including projects, services, and site settings."}],["$","meta","2",{"name":"robots","content":"noindex, nofollow"}],["$","link","3",{"rel":"icon","href":"/favicon.png"}],["$","$L14","4",{}]],"error":null,"digest":"$undefined"}
12:"$d:metadata"
